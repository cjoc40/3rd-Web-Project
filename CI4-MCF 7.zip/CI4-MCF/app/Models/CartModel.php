<?php

namespace App\Models;

use CodeIgniter\Model;

class CartModel extends Model
{
    protected $table = 'cart';
    protected $primaryKey = 'id';
    protected $allowedFields = ['session_id', 'product_id', 'quantity'];

    public function addItem($data)
    {
        $exists = $this->where('session_id', $data['session_id'])
            ->where('product_id', $data['product_id'])
            ->first();

        if ($exists) {
            $this->update($exists['id'], ['quantity' => $data['quantity'] + $exists['quantity']]);
        } else {
            $this->insert($data);
        }
    }

    public function getItemsBySession($sessionId)
    {
        $builder = $this->db->table('cart');

        $builder->select('cart.*,
            products.productID,
            products.price,
            cart.quantity as cartQuantity,
            products.quantity as productQuantity');

        $builder->join('products', 'products.productID = cart.product_id');
        $builder->where('cart.session_id', $sessionId);

        $query = $builder->get();

        return $query->getResult();
    }

    public function removeItem($sessionId, $productId)
    {
        $item = $this->where('session_id', $sessionId)
            ->where('product_id', $productId)
            ->first();

        if ($item) {
            if ($item['quantity'] > 1) {
                $this->set('quantity', 'quantity - 1', false)
                    ->where('session_id', $sessionId)
                    ->where('product_id', $productId)
                    ->update();
            } else {
                $this->where('session_id', $sessionId)
                    ->where('product_id', $productId)
                    ->delete();
            }
        }
    }

    public function updateItemQuantity($sessionId, $productId, $quantity)
    {
        $this->where('session_id', $sessionId)
            ->where('product_id', $productId)
            ->set('quantity', $quantity)
            ->update();
    }
}
