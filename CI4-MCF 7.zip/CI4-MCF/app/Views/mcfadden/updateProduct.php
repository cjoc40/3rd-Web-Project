<!DOCTYPE html>
<html lang="en">
<?php
$base = base_url() . "/";
$controller_base = $base . "admin.php/";
?>

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo $base . "assets/css/cart2.css" ?>">
  <link rel="stylesheet" href="<?php echo $base . "assets/vendors/css/vendor.bundle.base.css" ?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link href="<?php echo $base . "assets/css/admin.css" ?>" rel="stylesheet" type="text/css" />
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo $base . "assets/images/favicon.PNG " ?>" />
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>McFaddens - Admin</title>


  <link href="<?php echo $base . "assets/css/style.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/main.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/responsive.css" ?>" rel="stylesheet" type="text/css" />
<body>
   <style>
  .nav-links li {
    margin-top: 30px;
  }

  .content-wrapper {
    margin-top: 60px;
    /* Adjust the value as needed for the desired top space */
  }

  table {
    border-collapse: collapse;
    width: 100%;
  }

  th,
  td {
    border: 1px solid #000;
    padding: 8px;
    text-align: left;
  }

  th {
    background-color: #f2f2f2;
  }

  tr:nth-child(even) {
    background-color: #f2f2f2;
  }
</style>

</style>

<body>
  <div class="image-container always-on-top">
    <nav>

      <div class="wrapper">

        <div class="logo"><a href="#">McFaddens</a></div>
        <input type="radio" name="slider" id="menu-btn">
        <input type="radio" name="slider" id="close-btn">
        <ul class="nav-links">
          <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
          <li><a href="#">Home</a></li>
          <li><a href="#">Blog</a></li>

          <li>
            <input type="checkbox" id="showMega">
            <label for="showMega" class="mobile-item">Catalog</label>
            <div class="mega-box">
              <div class="content">
                <!--
              <div class="row">
                <img src="img.jpg" alt="">
              </div>
-->
          <li>
            <a href="#" class="desktop-item">Pages</a>
            <input type="checkbox" id="showDrop">
            <label for="showDrop" class="mobile-item">Pages</label>
            <ul class="drop-menu">
              <li><a href="#">About Us</a></li>
              <li><a href="#">FAQ</a></li>
              <li><a href="#">Contact Us</a></li>
              <li><a href="<?php echo base_url('admin'); ?>">Admin</a>
            </ul>
          </li>

          <a href="#cart"><img src="<?php echo $base . "assets/images/cart.png" ?>"></a>

      </div>
  </div>
  </li>
  </ul>
  </div>

  </nav>
  </div>

  <div class="d-flex align-items-center justify-content-between">
    <a href="https://www.bootstrapdash.com/product/purple-bootstrap-admin-template/"><i
        class="mdi mdi-home me-3 text-white"></i></a>
    <button id="bannerClose" class="btn border-0 p-0">
      <i class="mdi mdi-close text-white me-0"></i>
    </button>
  </div>
  </div>
  </div>
  </div>
  <!-- partial:partials/_navbar.html -->


  <div class="navbar-menu-wrapper d-flex align-items-stretch">
    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
      <span class="mdi mdi-menu"></span>
    </button>


    <li class="nav-item nav-logout d-none d-lg-block">
      <a class="nav-link" href="#">
        <i class="mdi mdi-power"></i>
      </a>
    </li>
    <li class="nav-item nav-settings d-none d-lg-block">
      <a class="nav-link" href="#">
        <i class="mdi mdi-format-line-spacing"></i>
      </a>
    </li>
    </ul>
    <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
      data-toggle="offcanvas">
      <span class="mdi mdi-menu"></span>
    </button>
  </div>
  </nav>
  <!-- partial -->
  <div class="container-fluid page-body-wrapper">
    <!-- partial:partials/_sidebar.html -->
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav">
        <li class="nav-item nav-profile">
          <a href="#" class="nav-link">
            <div class="nav-profile-image">


              <span class="login-status online"></span>
              <!--change to offline or busy as needed-->
            </div>

            <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('admin');?>">
            <span class="menu-title">Dashboard</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('index.php');?>">
            <span class="menu-title" >Home</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('viewMembers');?>">
            <span class="menu-title" >Members</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('viewProduct');?>">
            <span class="menu-title" >Products</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('viewStaff');?>">
            <span class="menu-title" >Staff</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('viewCategories');?>">
            <span class="menu-title" >Categories</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
     
      </ul>
    </nav>
    <!-- partial -->
    <div class="main-panel">
      <div class="content-wrapper">
        <div class="page-header">

          <nav aria-label="breadcrumb">
            <ul class="breadcrumb">
              <li class="breadcrumb-item active" aria-current="page">
                <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
              </li>
            </ul>
          </nav>
        </div>
<div style="margin-top: 4em; margin-left: 10%; width: 80%;">
  <div style="display: flex; justify-content: center;">
    <div style="width: 60%;">
      <div style="border: 1px solid #ddd; padding: 1em;">
        <!-- Update the 'action' attribute to point to the correct controller method -->
        <form action="<?= site_url('updateProduct' . $product->productID); ?>" method="post">

    
    <div>

        <input type="hidden" name="productID"  id="productID" value="<?= $product->productID ?>">
    </div>

    
    <div>
        <?= isset($validation) ? $validation->getError('warehouseID') : '' ?>
    </div>
    <div >
        <label for="warehouseID">warehouseID:</label>
        <input type="text" name="warehouseID"  id="warehouseID"  value="<?= $product->warehouseID ?>">
    </div>

	 <div>
        <?= isset($validation) ? $validation->getError('supplierID') : '' ?>
    </div>
    <div style="margin-bottom: 1em;">
        <label for="supplierID">supplierID:</label>
        <input type="text" name="supplierID"  id="supplierID"  value="<?= $product->supplierID ?>">
    </div>

    <div>
        <?= isset($validation) ? $validation->getError('barcode') : '' ?>
    </div>
    <div >
        <label for="barcode" >barcode:</label>
        <input type="text" name="barcode"  id="barcode"  value="<?= $product->barcode ?>">
    </div>
	 <div>
        <?= isset($validation) ? $validation->getError('brand') : '' ?>
    </div>
    <div >
        <label for="brand" >brand:</label>
        <input type="text" name="brand"  id="brand"  value="<?= $product->brand ?>">
    </div>

   
    <div>
        <?= isset($validation) ? $validation->getError('productDesc') : '' ?>
    </div>
    <div>
        <label for="productDesc" >Product Desc:</label>
        <input type="text" name="productDesc"  value="<?= $product->productDesc ?>">
    </div>

  
    <div>
        <?= isset($validation) ? $validation->getError('price') : '' ?>
    </div>
    <div >
        <label for="price" >Price (€):</label>
        <input type="text" name="price"  value="<?= $product->price ?>">
    </div>

    <!-- Display validation error for Quantity -->
    <div >
        <?= isset($validation) ? $validation->getError('quantity') : '' ?>
    </div>
    <div >
        <label for="admin-lastname" >Quantity:</label>
        <input type="text" name="quantity" value="<?= $product->quantity ?>">
    </div>
	<div >
        <label for="admin-lastname" >productAvailability:</label>
        <input type="text" name="productAvailability" value="<?= $product->productAvailability ?>">
    </div>
            <button type="submit" >Update Product</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>