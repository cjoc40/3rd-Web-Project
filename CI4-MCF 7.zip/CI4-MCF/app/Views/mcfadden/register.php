<!DOCTYPE html>
<html lang="en">
<?php
$base = base_url() . "/";
$controller_base = $base . "register.php/";
?>

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
  <link href="<?php echo $base . "assets/css/admin.css" ?>" rel="stylesheet" type="text/css" />
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo $base . "assets/images/favicon.PNG " ?>" />
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>McFaddens - Admin</title>

  <link href="<?php echo $base . "assets/css/login.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/main.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/responsive.css" ?>" rel="stylesheet" type="text/css" />
</head>


<body>
  
        

  <div class="d-flex align-items-center justify-content-between">
    
    <button id="bannerClose" class="btn border-0 p-0">
      <i class="mdi mdi-close text-white me-0"></i>
    </button>
  </div>
  </div>
  </div>
  </div>
<div class="form-container">
<ul class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
  <li class="nav-item" role="presentation">
    <a class="nav-link " id="tab-login" data-mdb-toggle="pill" href="<?php echo base_url('login'); ?>" role="tab"
      aria-controls="pills-login" aria-selected="true">Login</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link active" id="tab-register" data-mdb-toggle="pill" href="#pills-register" role="tab"
      aria-controls="pills-register" aria-selected="false">Register</a>
  </li>
</ul>
<form method="post" action="<?php echo base_url('/register'); ?>">
      <!-- Name input -->
      <div class="form-outline mb-4">
	  <label class="form-label" for="name">Name</label>
        <input  required type="text" id="name" name="name" class="form-control" />
        
      </div>

      <!-- Username input -->
      <div class="form-outline mb-4">
	  <label class="form-label" for="username">Username</label>
        <input required type="text" id="username" name="username" class="form-control" />
        
      </div>

      <!-- Email input -->
      <div class="form-outline mb-4">
	   <label class="form-label" for="email">Email</label>
        <input required type="email" id="email" name="email" class="form-control" />
       
      </div>

      <!-- Password input -->
      <div class="form-outline mb-4">
	  <label class="form-label" for="password">Password</label>
        <input required type="password" id="password" name="password" class="form-control" />
        
      </div>

      

      <!-- Checkbox -->
      <div class="form-check d-flex justify-content-center mb-4">
        <input class="form-check-input me-2" type="checkbox" value="" name="registerCheck" id="registerCheck"
          aria-describedby="registerCheckHelpText" />
        <label class="form-check-label" for="registerCheck">
          I have read and agree to the terms
        </label>


      <!-- Submit button -->
      <button type="submit" value ="register" class="btn btn-primary btn-block mb-3">Sign in</button>
    </form>
  </div>
</div>
</div>
<a href="<?php echo $base . "index.php" ?>">Go Back</a>
<!-- Pills content -->
</html>
  