<!DOCTYPE html>
<html lang="en">
<?php
$base = base_url() . "/";
$controller_base = $base . "login.php/";
?>

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="<?php echo $base . "assets/css/admin.css" ?>" rel="stylesheet" type="text/css" />
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo $base . "assets/images/favicon.PNG " ?>" />
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>McFaddens - Admin</title>

  <link href="<?php echo $base . "assets/css/login.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/main.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/responsive.css" ?>" rel="stylesheet" type="text/css" />
</head>


<body>


  <div class="d-flex align-items-center justify-content-between">

    <button id="bannerClose" class="btn border-0 p-0">
      <i class="mdi mdi-close text-white me-0"></i>
    </button>
  </div>
  </div>
  </div>
  </div>
  <div class="form-container">
    <ul class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
      <li class="nav-item" role="presentation">
        <a class="nav-link active" id="tab-login" data-mdb-toggle="pill" href="#pills-login" role="tab"
          aria-controls="pills-login" aria-selected="true">Login</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="tab-register" data-mdb-toggle="pill" href="<?php echo base_url('register'); ?>"
          role="tab" aria-controls="pills-register" aria-selected="false">Register</a>
      </li>
    </ul>

    <div class="tab-content">
      <div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
        <form method="post" action="<?php echo base_url('login'); ?>">
          <div class="text-center mb-3">
            <p>Sign in with:</p>
            <button type="button" class="btn btn-link btn-floating mx-1">
              <i class="fab fa-facebook-f"></i>
            </button>

            <button type="button" class="btn btn-link btn-floating mx-1">
              <i class="fab fa-google"></i>
            </button>

            <button type="button" class="btn btn-link btn-floating mx-1">
              <i class="fab fa-twitter"></i>
            </button>

            <button type="button" class="btn btn-link btn-floating mx-1">
              <i class="fab fa-github"></i>
            </button>
          </div>

          <p class="text-center">or:</p>

          <!-- Email input -->
          <div class="form-outline mb-4">
            <input required type="email" id="email" name="email" class="form-control" />
            <label class="form-label" for="email">Email</label>
          </div>

          <!-- Password input -->
          <div class="form-outline mb-4">
            <input required type="password" id="password" name="password" class="form-control" />
            <label class="form-label" for="password">Password</label>
          </div>

          <!-- 2 column grid layout -->
          <div class="row mb-4">
            <div class="col-md-6 d-flex justify-content-center">
              <!-- Checkbox -->
              <div class="form-check mb-3 mb-md-0">
                <input class="form-check-input" type="checkbox" value="" id="loginCheck" checked />
                <label class="form-check-label" for="loginCheck"> Remember me </label>
              </div>
            </div>

            <div class="col-md-6 d-flex justify-content-center">
              <!-- Simple link -->
              <a href="#!">Forgot password?</a>
            </div>
          </div>

          <!-- Submit button -->
          <button type="submit" class="btn btn-primary btn-block mb-4">Sign in</button>

          <!-- Register buttons -->
          <div class="text-center">
            <p>Not a member? <a href="#!">Register</a></p>
          </div>
        </form>
      </div>
      <div class="tab-pane fade" id="pills-register" role="tabpanel" aria-labelledby="tab-register">
        <form>
          <div class="text-center mb-3">
            <p>Sign up with:</p>
            <button type="button" class="btn btn-link btn-floating mx-1">
              <i class="fab fa-facebook-f"></i>
            </button>

            <button type="button" class="btn btn-link btn-floating mx-1">
              <i class="fab fa-google"></i>
            </button>

            <button type="button" class="btn btn-link btn-floating mx-1">
              <i class="fab fa-twitter"></i>
            </button>

            <button type="button" class="btn btn-link btn-floating mx-1">
              <i class="fab fa-github"></i>
            </button>
          </div>

          <p class="text-center">or:</p>


          <!-- Submit button -->
          <input type="submit" value="Login" class="btn btn-primary btn-block mb-3">Sign in</input>
        </form>
      </div>
    </div>
  </div>
  <a href="<?php echo $base . "index.php" ?>">Go Back</a>
  <!-- Pills content -->

</html>