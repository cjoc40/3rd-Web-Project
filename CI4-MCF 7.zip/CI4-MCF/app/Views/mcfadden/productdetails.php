<?php
/* Loads the form and url helper */	
helper(['url', 'form']);

$base = base_url() .  "/productdetails.php/"; 
$img_base = base_url() .  "/assets/images";



?>

</script>
<?php echo form_open('/home/handleCustomerActivity/'.$product['productId']); ?>


  <div class="navbar-menu-wrapper d-flex align-items-stretch">
    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
      <span class="mdi mdi-menu"></span>
    </button>


    <li class="nav-item nav-logout d-none d-lg-block">
      <a class="nav-link" href="#">
        <i class="mdi mdi-power"></i>
      </a>
    </li>
    <li class="nav-item nav-settings d-none d-lg-block">
      <a class="nav-link" href="#">
        <i class="mdi mdi-format-line-spacing"></i>
      </a>
    </li>
    </ul>
    <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
      data-toggle="offcanvas">
      <span class="mdi mdi-menu"></span>
    </button>
  </div>
  </nav>
  <!-- partial -->
  <div class="container-fluid page-body-wrapper">
    <!-- partial:partials/_sidebar.html -->
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav">
        <li class="nav-item nav-profile">
          <a href="#" class="nav-link">
            <div class="nav-profile-image">


              <span class="login-status online"></span>
              <!--change to offline or busy as needed-->
            </div>

            <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('admin');?>">
            <span class="menu-title">Dashboard</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('index.php');?>">
            <span class="menu-title" >Home</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('viewMembers');?>">
            <span class="menu-title" >Members</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('viewProduct');?>">
            <span class="menu-title" >Products</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('viewStaff');?>">
            <span class="menu-title" >Staff</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('viewCategories');?>">
            <span class="menu-title" >Categories</span>
            <i class="mdi mdi-home menu-icon"></i>
          </a>
        </li>
     
      </ul>
    </nav>

<form id="form1" name="form1" method="post" >

 <!-- Create form to insert all data from Customer table -->
 <label for ="productId">Details for Product:</label>
 <input type="text" name="productId" id="productId" value="<?=$product['productId']?>"><br>
  
	<label for ="warehouseID">warehouseID:</label>
    <input type="text" name="warehouseID" id="warehouseID" value="<?=$product['productName']?>"><br>
	<?php if (isset($validation)) { echo $validation->getError('productName'); }?><br/>
	<label for ="productDescription">Product Description:</label>
	<input type="text" name="productDescription" id="productDescription" value="<?=$product['productDescription']?>"><br>
	<?php if (isset($validation)) { echo $validation->getError('productDescription'); }?><br/>
	<label for ="add_date">Product Add Date:</label>
	<input type="text" name="add_date" id="add_date" value="<?=$product['add_date']?>"><br>
	<?php if (isset($validation)) { echo $validation->getError('add_date'); }?><br/>
	<label for ="modified_date">Product Modified Date:</label>
	<input type="text" name="modified_date" id="modified_date" value="<?=$customer['modified_date']?>"><br>
	<?php if (isset($validation)) { echo $validation->getError('modified_date'); }?><br/>
	
 
  <p>&nbsp;</p>
  <table width="553" border="0" cellpadding="5" cellspacing="5">
    <tr>
      <td><button input type="submit" name="insert" id="insert" value="Insert product"/>Insert Product</td>
      <td><button input type="submit" name="update" id="update" value="Update product"/>Update Product</td>
      <td><button input type="submit" name="delete" id="yes"  value="Delete product"/>Delete Product</td>			
    </tr>
	
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;  </p>
</form>
