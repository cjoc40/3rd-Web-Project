<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Validation\CreditCardRules;
use CodeIgniter\Validation\FileRules;
use CodeIgniter\Validation\FormatRules;
use CodeIgniter\Validation\Rules;

class Validation extends BaseConfig
{
    // --------------------------------------------------------------------
    // Setup
    // --------------------------------------------------------------------

    /**
     * Stores the classes that contain the
     * rules that are available.
     *
     * @var string[]
     */
    public $ruleSets = [
        Rules::class,
        FormatRules::class,
        FileRules::class,
        CreditCardRules::class,
    ];

    /**
     * Specifies the views that are used to display the
     * errors.
     *
     * @var array<string, string>
     */
    public $templates = [
        'list'   => 'CodeIgniter\Validation\Views\list',
        'single' => 'CodeIgniter\Validation\Views\single',
    ];

    // --------------------------------------------------------------------
    // Rules
    // --------------------------------------------------------------------
	
	
	public $validation = [
        'warehouseID' => [
            'rules' => 'required||max_length[10]',
            'errors' => [
                'required' => 'Must insert a value for {field}.',
                'max_length' => '{field} name must be less than {param} characters long.'
            ]
        ],
        
        'supplierID' => [
            'rules' => 'required||max_length[10]',
            'errors' => [
                'required' => 'Must insert a value for {field}.',
                'max_length' => '{field} name must be less than {param} characters long.'
            ]
        ],
        
        'barcode' => [
            'rules' => 'required|min_length[9]|max_length[15]',
            'errors' => [
                'required' => 'Must insert a value for {field}.',
                'min_length' => 'Barecode must be a minimum of {param} characters.',
                'max_length' => 'Barcode scale must be less than {param} characters long.'
            ]
        ],
        
        'brand' => [
            'rules' => 'required|',
            'errors' => [
                'required' => 'Must insert a value for contact first name.',
                
            ]
        ],
        
        'productDesc' => [
            'rules' => 'max_length[250]',
            'errors' => [
                'max_length' => 'Product description must be less than {param} characters long.'
            ]
        ],
        
       
        'price' => [
            'rules' => 'required|decimal|max_length[50]',
            'errors' => [
                'required' => 'Must insert a value for {field}.',
                'decimal' => '{field} must be a decimal value',
                'max_length' => 'Price must be less than {param} digits long.'
            ]
        ],
		'quantity' => [
            'rules' => 'required|numeric|max_length[6]',
            'errors' => [
                'required' => 'Must insert a value for quantity in stock.',
                'numeric' => 'Quantity in stock must be a numeric vlaue.',
                'max_length' => 'Quantity in stock must be less than 6 digits long.'
            ]
        ],
        
       'productAvailability' => [
            'rules' => 'required|numeric|max_length[6]',
            'errors' => [
                'required' => 'Must insert a value for quantity in stock.',
                'numeric' => 'Quantity in stock must be a numeric vlaue.',
                'max_length' => 'Quantity in stock must be less than 6 digits long.'
            ]
        ],
        
    ];
    
}
