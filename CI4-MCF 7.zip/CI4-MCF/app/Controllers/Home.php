<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class Home extends BaseController
{
    protected $db;
    protected $session;
    protected $shoppingCartController;

    public function __construct()
    {
        helper(['form', 'url']);

        $this->db = db_connect(); // Load the database
        $this->session = \Config\Services::session();
        $this->shoppingCartController = new ShoppingCartController();
    }

    public function index()
    {
        return view('mcfadden/index');
    }

    public function admin()
    {
        return view('mcfadden/admin');
    }
    public function cart()
    {
        return $this->shoppingCartController->viewCart();
    }
    public function login()
    {
        return view('mcfadden/login');
    }
    public function register()
    {
        return view('mcfadden/register');
    }
	
	
     public function addProduct()
    {
        // Fetch products and categories from the database
        $db = db_connect();
		$products = $db->query('SELECT p.*, c.categoryName FROM products p
                       LEFT JOIN category c ON p.categoryID = c.categoryID')
              ->getResult();
        $categories = $db->table('category')->get()->getResult();

        // Pass the products and categories to the view
        return view('mcfadden/addProduct', ['products' => $products, 'categories' => $categories]);
    }
public function updateProduct($productID){
    $db = db_connect();
    $data = [];
    
    if(empty($productID)){
        return redirect()->to('viewProduct');
    }
    
    if($this->request->getMethod() === 'post'){
        $validation = \Config\Services::validation();
        $validation->setRules($this->validation);
        
        if($validation->withRequest($this->request)->run()){
            $productData = [
                'productID' => $this->request->getPost('productID'),
                'categoryID' => $this->request->getPost('categoryID'),
                'warehouseID' => $this->request->getPost('warehouseID'),
                'supplierID' => $this->request->getPost('supplierID'),
                'barcode' => $this->request->getPost('barcode'),
                'brand' => $this->request->getPost('brand'),
                'productDesc' => $this->request->getPost('productDesc'),
                'price' => $this->request->getPost('price'),
                'quantity' => $this->request->getPost('quantity'),
                'productAvailability' => $this->request->getPost('productAvailability'),
            ];
            
            $db->table('products')->update($productData, ['productID' => $productID]);
            return redirect()->to('viewProduct');
            
        } else {
            $data['validation'] = $validation;
        }
    }
    
    $product = $db->table('products')->where('productID', $productID)->get()->getRow();
    $data['product'] = $product;

    return view('mcfadden/updateProduct', $data);
}

public function updateCategory($categoryID)
{
    $db = db_connect();
    $data = [];

    if ($this->request->getMethod() === 'post') {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'categoryName' => 'required|max_length[255]',
            'description' => 'required',
            'picture' => 'required|max_length[255]',
        ]);

        if ($validation->withRequest($this->request)->run()) {
            $categoryData = [
                'categoryName' => $this->request->getPost('categoryName'),
                'description' => $this->request->getPost('description'),
                'picture' => $this->request->getPost('picture'),
            ];

            $db->table('category')->update($categoryData, ['categoryID' => $categoryID]);
            return redirect()->to('viewCategories'); // Make sure 'viewCategory' is a valid route
        } else {
            $data['validation'] = $validation;
        }
    }

    $category = $db->table('category')->where('categoryID', $categoryID)->get()->getRow();
    $data['category'] = $category;

    return view('mcfadden/updateCategory', $data);
}




    public function viewStaff()
    {
        $db = db_connect();
        $query = $db->table('staff')->get();
        $data['staff'] = $query->getResult();
        return view('mcfadden/viewStaff', $data);
    }


    public function viewMembers()
    {
        $db = db_connect();
        $query = $db->table('member')->get();
        $data['members'] = $query->getResult();
        return view('mcfadden/viewMembers', $data);
    }


    public function viewCategories()
    {
        $db = db_connect();
        $query = $db->table('category')->get();
        $data['categories'] = $query->getResult();
        return view('mcfadden/viewCategories', $data);
    }
	public function viewProduct()
    {
        $db = db_connect();
        $query = $db->table('products')->get();
        $data['products'] = $query->getResult();
        return view('mcfadden/viewProduct', $data);
    }

    public function newMember()
    {
        return view('mcfadden/newMember');
    }
    public function newStaff()
    {
        return view('mcfadden/newStaff');
    }
    public function newProduct()
    {
        // Fetch categories from the database
        $db = db_connect();
        $categories = $db->table('category')->get()->getResult();

        // Pass the categories to the view
        return view('mcfadden/newProduct', ['categories' => $categories]);
    }
    public function newCategory()
    {
        return view('mcfadden/newCategory');
    }
	public function deleteMessage()
    {
        return view('mcfadden/deleteMessage');
    }

    public function addMember()
    {
        $db = db_connect();
		
		// Check if the form has been submitted
        if ($this->request->getMethod() === 'post') {

        // Retrieve member data from the form
        $memberData = [
            'firstName' => $this->request->getPost('firstName'),
            'lastName' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'phoneNum' => $this->request->getPost('phoneNum'),
            'passWord' => password_hash($this->request->getPost('passWord'), PASSWORD_BCRYPT),
            // Hash the password
            'address1' => $this->request->getPost('address1'),
            'address2' => $this->request->getPost('address2'),
            'town_city' => $this->request->getPost('town_city'),
            'county' => $this->request->getPost('county'),
        ];

        // Insert the data into the 'member' table
        $db->table('member')->insert($memberData);
			
		// Reset the auto-increment value to 1
        $db->query("ALTER TABLE products AUTO_INCREMENT = 1");

        // Redirect to the product list after adding
            return redirect()->to(base_url('viewMembers'));
      
    	}
		// If the form has not been submitted, just load the view without adding a product
        return view('mcfadden/viewMembers');
	}
    public function addProduct2()
    {
        $db = db_connect();
		
		
        // Check if the form has been submitted
        if ($this->request->getMethod() === 'post') {
			
			$categoryID = $this->request->getPost('categoryID');
			$categoryName = $this->request->getPost('categoryName');

            // Retrieve product data from the form
            $productData = [
                // Retrieve form data including the selected category ID
   				 'categoryID' => $categoryID,
                'warehouseID' => $this->request->getPost('warehouseID'),
                'supplierID' => $this->request->getPost('supplierID'),
                'barcode' => $this->request->getPost('barcode'),
                'brand' => $this->request->getPost('brand'),
                'productDesc' => $this->request->getPost('productDesc'),
                'price' => $this->request->getPost('price'),
                'quantity' => $this->request->getPost('quantity'),
                'productAvailability' => $this->request->getPost('productAvailability'),
            ];

            // Insert the data into the 'products' table
            $db->table('products')->insert($productData);

            // Reset the auto-increment value to 1
            $db->query("ALTER TABLE products AUTO_INCREMENT = 1");

            // Redirect to the product list after adding
            return redirect()->to('addProduct')->with('success', 'Product added successfully');
        }

        // If the form has not been submitted, just load the view without adding a product
        return view('mcfadden/addProduct');
    }
	
	public function addCategory()
    {
        $db = db_connect();

        // Check if the form has been submitted
        if ($this->request->getMethod() === 'post') {

            // Retrieve product data from the form
            $categoryData = [
                'categoryID' => $this->request->getPost('categoryID'),
                'categoryName' => $this->request->getPost('categoryName'),
            ];

            // Insert the data into the 'category' table
            $db->table('category')->insert($categoryData);

            // Reset the auto-increment value to 1
            $db->query("ALTER TABLE category AUTO_INCREMENT = 1");

            // Redirect to the product list after adding
            return redirect()->to(base_url('viewCategories'));
        }

        // If the form has not been submitted, just load the view without adding a product
        return view('mcfadden/viewCategories');
    }
public function deleteProduct($productID)
{
      if ($this->request->isAJAX()) {
        // If the request is AJAX, it means it's coming from the confirmation dialog
		  
		log_message('debug', 'AJAX request received');  
		  
        $db = db_connect();
        
        // Delete the product
        $db->table('products')->where('productID', $productID)->delete();
        
        // Get the current maximum productID value
        $maxIDQuery = $db->query("SELECT MAX(productID) as maxID FROM products");
        $maxIDResult = $maxIDQuery->getRow();
        $maxID = $maxIDResult->maxID;
        
        // Reset the auto-increment value
        $newAutoIncrementValue = $maxID + 1;
        $db->query("ALTER TABLE products AUTO_INCREMENT = $newAutoIncrementValue");
		  
		  // Debugging: Add a log statement to check if there are any errors
		  log_message('debug', 'Deletion and reset successful');
        
        // Return a success message (this will be sent back to the AJAX request)
        return $this->response->setJSON(['status' => 'success', 'message' => 'Product deleted successfully']);
		 
    
}
			return view('mcfadden/deleteMessageP', ['productID' => $productID]);
	

}
	public function deleteMember($memberID)
{
      if ($this->request->isAJAX()) {
        // If the request is AJAX, it means it's coming from the confirmation dialog
		  
		log_message('debug', 'AJAX request received');  
		  
        $db = db_connect();
        
        // Delete the product
        $db->table('member')->where('memberID', $memberID)->delete();
        
        // Get the current maximum productID value
        $maxIDQuery = $db->query("SELECT MAX(memberID) as maxID FROM member");
        $maxIDResult = $maxIDQuery->getRow();
        $maxID = $maxIDResult->maxID;
        
        // Reset the auto-increment value
        $newAutoIncrementValue = $maxID + 1;
        $db->query("ALTER TABLE member AUTO_INCREMENT = $newAutoIncrementValue");
		  
		  // Debugging: Add a log statement to check if there are any errors
		  log_message('debug', 'Deletion and reset successful');
        
        // Return a success message (this will be sent back to the AJAX request)
        return $this->response->setJSON(['status' => 'success', 'message' => 'Member deleted successfully']);
		 
    
}
			return view('mcfadden/deleteMessageM', ['memberID' => $memberID]);
	

}
    
   public function deleteCategory($categoryID)
{
      if ($this->request->isAJAX()) {
        // If the request is AJAX, it means it's coming from the confirmation dialog
		  
		log_message('debug', 'AJAX request received');  
		  
        $db = db_connect();
        
        // Delete the product
        $db->table('category')->where('categoryID', $categoryID)->delete();
        
        // Get the current maximum productID value
        $maxIDQuery = $db->query("SELECT MAX(categoryID) as maxID FROM category");
        $maxIDResult = $maxIDQuery->getRow();
        $maxID = $maxIDResult->maxID;
        
        // Reset the auto-increment value
        $newAutoIncrementValue = $maxID + 1;
        $db->query("ALTER TABLE category AUTO_INCREMENT = $newAutoIncrementValue");
		  
		  // Debugging: Add a log statement to check if there are any errors
		  log_message('debug', 'Deletion and reset successful');
        
        // Return a success message (this will be sent back to the AJAX request)
        return $this->response->setJSON(['status' => 'success', 'message' => 'Category deleted successfully']);
		 
    
}
			return view('mcfadden/deleteMessageC', ['categoryID' => $categoryID]);
	

}
    
    public function addStaff()
    {
        $db = db_connect();

        // Retrieve staff data from the form
        $staffData = [
            'firstName' => $this->request->getPost('firstName'),
            'lastName' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'phoneNum' => $this->request->getPost('phoneNum'),
            'passWord' => password_hash($this->request->getPost('passWord'), PASSWORD_BCRYPT),
            'positions' => $this->request->getPost('positions'),
            'permissions' => $this->request->getPost('permissions'),
            'hireDate' => $this->request->getPost('hireDate'),
            'dateOfBirth' => $this->request->getPost('dateOfBirth'),
        ];

        // Insert the data into the 'staff' table
        $db->table('staff')->insert($staffData);

        $query = $db->table('staff')->get();
        $data['staff'] = $query->getResult();

        return view('mcfadden/viewStaff', $data); // Redirect to the staff list after adding
    }

    public function queryDatabase()
    {
        $query = $this->db->query("SELECT * FROM your_table_name");
        $result = $query->getResult();

        foreach ($result as $row) {
            echo $row->column_name . "<br>";
        }
    }

    public function do_register()
{
    $userModel = new UserModel();

    $name = $this->request->getPost('name');
    $username = $this->request->getPost('username');
    $email = $this->request->getPost('email');
    $password = $this->request->getPost('password');

    // Trim the password to remove any leading or trailing whitespaces
    $password = trim($password);

    // Hash the password
    $hash_password = password_hash($password, PASSWORD_DEFAULT);

    // Debugging: Print password and hashed password
    echo "Password before hashing: " . $password . "<br>";
    echo "Hash from registration: " . $hash_password . "<br>";

    // Prepare data for insertion
    $data = ['name' => $name, 'username' => $username, 'email' => $email, 'password' => $hash_password];

    // Insert data into the database
    $r = $userModel->insert($data);

    if ($r) {
        return view('mcfadden/login');
    } else {
        echo "Error in the registration process";
    }
}

    
   public function do_login()
{
    $userModel = new UserModel();

    $email = $this->request->getPost('email');
    $password = $this->request->getPost('password');

    // Retrieve user data from the database based on the email
    $result = $userModel->where('email', $email)->first();

    if ($result) {
        // Debugging: Print email, hashed password from the database, and hashed password from login attempt
        // Debugging: Print email, raw password from the form, hashed password from the database, and hashed password from login attempt
echo "Email: " . $email . "<br>";
echo "Raw Password from Form: " . $password . "<br>";
echo "Hash from DB: " . $result->password . "<br>";
echo "Hash from Login: " . password_hash($password, PASSWORD_DEFAULT) . "<br>";


        // Check if the entered password matches the hashed password from the database
        if (password_verify($password, $result->password)) {
    // Check if rehash is needed
    if (password_needs_rehash($result->password, PASSWORD_DEFAULT)) {
        // Rehash the password and update it in the database
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        // Update $result->password with $newHash in the database
    }
    $this->session->set("users", $result);
    return redirect()->to('/admin');
} else {
    echo "Password is not valid";
}

}
}
}
