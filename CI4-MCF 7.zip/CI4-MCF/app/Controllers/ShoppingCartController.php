<?php

namespace App\Controllers;

use App\Models\CartModel;

/*
CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    product_id VARCHAR(10) NOT NULL,
    quantity INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(productID)
) ENGINE=InnoDB;
*/

class ShoppingCartController extends BaseController
{
    protected $cartModel;
    protected $session;

    public function __construct()
    {
        $this->cartModel = new CartModel();
        helper(['form', 'url']);
        $this->session = \Config\Services::session();
    }

    public function addToCart()
    {
        $productId = $this->request->getPost('product_id');
        $quantity = $this->request->getPost('quantity');

        $cartData = [
            'session_id' => $this->session->session_id,
            'product_id' => $productId,
            'quantity' => $quantity
        ];

        $this->cartModel->addItem($cartData);

        return redirect()->to('/cart');
    }

    private function getPriceFloat($price): float
    {
        $price = preg_replace('/[^0-9.]/', '', $price);
        return (float) $price;
    }

    public function viewCart()
    {
        $sessionId = $this->session->session_id;

        $data['cartItems'] = $this->cartModel->getItemsBySession($sessionId);
        $data['totalPrice'] = 0;
        $data['totalItems'] = 0;

        foreach ($data['cartItems'] as $item) {
            $data['totalPrice'] += $this->getPriceFloat($item->price) * $item->cartQuantity;
            $data['totalItems'] += $item->cartQuantity;
        }

        echo view('mcfadden/cart', $data);
    }

    public function updateCart()
    {
        $sessionId = $this->session->session_id;

        $productIds = $this->request->getPost('product_id');
        $quantities = $this->request->getPost('quantity');

        foreach ($productIds as $index => $productId) {
            $quantity = $quantities[$index];
            $this->cartModel->updateItemQuantity($sessionId, $productId, $quantity);
        }

        return redirect()->to('/cart');
    }

    public function removeFromCart($productId)
    {
        $sessionId = $this->session->session_id;

        $this->cartModel->removeItem($sessionId, $productId);

        return redirect()->to('/cart');
    }
}
