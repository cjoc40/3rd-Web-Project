<!DOCTYPE html>
<html lang="en">

<?php

$base = base_url() . "/";

$controller_base = $base . "index.php/";


?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>McFaddens - Home</title>

  <link href="<?php echo $base . "assets/css/style.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/main.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/responsive.css" ?>" rel="stylesheet" type="text/css" />
</head>


<body>
  <!-- Navbar -->
  <div class="image-container always-on-top">
    <nav>

      <div class="wrapper">

        <div class="logo"><a href="#">McFaddens</a></div>
        <input type="radio" name="slider" id="menu-btn">
        <input type="radio" name="slider" id="close-btn">
        <ul class="nav-links">
          <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
          <li><a href="#">Home</a></li>
          <li><a href="#">Blog</a></li>

          <li>
            <a href="#" class="desktop-item">Catalog</a>
            <input type="checkbox" id="showMega">
            <label for="showMega" class="mobile-item">Catalog</label>
            <div class="mega-box">
              <div class="content">
                <!--
              <div class="row">
                <img src="img.jpg" alt="">
              </div>
-->
                <div class="row">
                  <header>Acuoustic Nylon String</header>
                  <ul class="mega-links">
                    <li><a href="#">Goniry</a></li>
                    <li><a href="#">Koniry</a></li>
                    <li><a href="#">Wengty</a></li>
                    <li><a href="#">Zassy</a></li>
                    <li><a href="#">Lassuca</a></li>
                  </ul>
                </div>
                <div class="row">
                  <header>Acuoustic Steel String </header>
                  <ul class="mega-links">
                    <li><a href="#">Goroly</a></li>
                    <li><a href="#">Ligglo</a></li>
                    <li><a href="#">Wirmon</a></li>
                    <li><a href="#">Ziyara</a></li>
                    <li><a href="#">Nesica</a></li>
                  </ul>
                </div>
                <div class="row">
                  <header>Bass Guitar</header>
                  <ul class="mega-links">
                    <li><a href="#">Kidsor</a></li>
                    <li><a href="#">Nozzby</a></li>
                    <li><a href="#">Yorbax</a></li>
                    <li><a href="#">Sandria</a></li>
                    <li><a href="#">Alfare</a></li>
                  </ul>
                </div>
                <div class="row">
                  <header>Electric Guitar</header>
                  <ul class="mega-links">
                    <li><a href="#">Konicy</a></li>
                    <li><a href="#">Rovty</a></li>
                    <li><a href="#">Zoniry</a></li>
                    <li><a href="#">Hendry</a></li>
                    <li><a href="#">Lyrica</a></li>
                  </ul>
                </div>
          <li>
            <a href="#" class="desktop-item">Pages</a>
            <input type="checkbox" id="showDrop">
            <label for="showDrop" class="mobile-item">Pages</label>
            <ul class="drop-menu">
              <li><a href="#">About Us</a></li>
              <li><a href="#">FAQ</a></li>
              <li><a href="#">Contact Us</a></li>
              <!--  <li><a href="<?php echo base_url('admin'); ?>">Admin</a></li>-->

              <?php if (session()->get('isLoggedIn')): ?>
                <?php if (session()->get('isAdmin')): ?>
                  <li><a href="<?php echo base_url('admin'); ?>">Admin</a></li>
                <?php endif; ?>
                <li><a href="<?php echo base_url('logout'); ?>">Logout</a></li>
              <?php else: ?>
                <li>
                  <a href="<?php echo base_url('login'); ?>">Login</a>
                  <a href="<?php echo base_url('register'); ?>">Register</a>
                </li>
              <?php endif; ?>

            </ul>
          </li>

          <a href="<?php echo base_url('cart'); ?>"><img src="<?php echo $base . "assets/images/cart.png" ?>"></a>

      </div>
  </div>
  </li>
  </ul>
  </div>

  </nav>
  </div>

  <!-- Header -->
  <header class="hero" style="background-image: url('<?php echo $base . "assets/images/hero.jpg" ?>');">
    <div class="hero-content">
      <h1 class="h1 largest khula-bold">Your One-Stop Shop For<br>All Your Musical Needs</h1>
      <button class="outline-button medium khula-bold">Find Your Perfect Instrument</button>
    </div>
  </header>

  <!-- Main -->
  <div class="grid-container">

    <h1 class="heading">FREE GUITAR LESSONS!</h1>
    <h3 class="h3">Purchase any guitar over $499.99 and recieve</h3>
    <h3 class="h3">a one-hour guitar lesson free.</h3>
    <div class="alignbtn"><button class="button-59" role="button">LEARN MORE</button></div>

    <div class="box-container">


      <div class="box">
        <img src="<?php echo $base . "./assets/images/g1.jpg" ?>">
        <!-- <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Brand Name<span style="float:right;">$2,995</span></h3>
        <p style="text-align:left;">Product description here</p>
        <a href="<?php echo base_url('productdetails'); ?>" class="btn">View</a>
      </div>


      <div class="box">
        <img src="<?php echo $base . "./assets/images/g2.jpg" ?> ">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Brand Name<span style="float:right;">$2,995</span></h3>
        <p style="text-align:left;">Product description here</p>
        <a href="#" class="btn">View</a>
      </div>

      <div class="box">
        <img src="<?php echo $base . "./assets/images/g3.jpg" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Brand Name<span style="float:right;">$2,995</span></h3>
        <p style="text-align:left;">Product description here</p>
        <a href="#" class="btn">View</a>
      </div>


    </div>


    <div class="breakline"></div>
    <h1 class="h3">Popular Finds</h1>

    <div class="box-container2">

      <div class="box2">
        <img src="<?php echo $base . "./assets/images/c1.jpg" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Brand Name<span style="float:right;">$2,995</span></h3>
        <p style="text-align:left;">Product description here</p>
        <a href="#" class="btn">View</a>
      </div>

      <div class="box2">
        <img src="<?php echo $base . "./assets/images/ear.jpg" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Brand Name<span style="float:right;">$2,995</span></h3>
        <p style="text-align:left;">Product description here</p>
        <a href="#" class="btn">View</a>
      </div>

      <div class="box2">
        <img src="<?php echo $base . "./assets/images/ipod.jpg" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Brand Name<span style="float:right;">$2,995</span></h3>
        <p style="text-align:left;">Product description here</p>
        <a href="#" class="btn">View</a>
      </div>


    </div>

    <div class="breakline"></div>
    <h1 class="h3">Gear Heads</h1>

    <div class="box-container3">

      <div class="box3">
        <img src="<?php echo $base . "./assets/images/article1.jpg" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Article Title</h3>
        <p style="text-align:left;">Article Subhead</p>
      </div>

      <div class="box3">
        <img src="<?php echo $base . "./assets/images/article2.jpg" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Article Title</h3>
        <p style="text-align:left;">Article Subhead</p>
      </div>

      <!--
        <div class="box2">
            <img src="../WebProject/images/ipod.jpg" alt="">
            <h3>Brand Name</h3>
            <h3 style="text-align:left;">Brand Name<span style="float:right;">$2,995</span></h3>
            <p style="text-align:left;">Product description here</p>
            <a href="#" class="btn">View</a>
        </div>
-->


    </div>


    <div class="box-container4">

      <div class="box4">
        <img src="<?php echo $base . "./assets/images/article3.jfif" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Article Title</h3>
        <p style="text-align:left;">Article Subhead</p>
      </div>

      <div class="box4">
        <img src="<?php echo $base . "./assets/images/article4.jpg" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Article Title</h3>
        <p style="text-align:left;">Article Subhead</p>
      </div>

      <div class="box4">
        <img src="<?php echo $base . "./assets/images/article5.jpg" ?>">
        <!--            <h3>Brand Name</h3>-->
        <h3 style="text-align:left;">Article Title</h3>
        <p style="text-align:left;">Article Subhead</p>
      </div>

    </div>

  </div>


  <footer class="footer">
    <p class="khula-regular">&#169; 2023 McFaddens Instruments. All rights reserved.</p>
    <?php if (session()->get('isLoggedIn')): ?>
      <p class="khula-regular">Session ID: <?php echo session_id(); ?></p>
      <?php if (session()->get('isAdmin')): ?>
        <p class="khula-regular"><a href="<?php echo base_url('admin'); ?>">Admin</a></p>
      <?php endif; ?>
      <p class="khula-regular"><a href="<?php echo base_url('logout'); ?>">Logout</a></p>
    <?php else: ?>
      <p class="khula-regular"><a href="<?php echo base_url('login'); ?>">Login</a></p>
      <p class="khula-regular"><a href="<?php echo base_url('register'); ?>">Register</a></p>
    <?php endif; ?>
  </footer>
</body>

</html>