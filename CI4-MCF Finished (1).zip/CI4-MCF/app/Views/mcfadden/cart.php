<!DOCTYPE html>
<html lang="en">

<head>
    <title>Shopping Cart</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/cart.css") ?>">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <br>
    <div class="container">
        <a href="<?php echo base_url(''); ?>" class="go-back-link">
            <i class="fa fa-arrow-left" aria-hidden="true"></i>
            <span>Go Back Home</span>
        </a>
        <h1>Shopping Cart</h1>
        <div class="cart">
            <div class="products">
                <?php foreach ($cartItems as $item) : ?>
                    <div class="product">
                        <img src="<?php echo base_url("assets/images/g{$item->productID}.jpg"); ?>" alt="Product Image">
                        <div class="product-info">
                            <h3 class="product-name">
                                <?php echo $item->name; ?>
                            </h3>
                            <p class="product-quantity">Quantity: <?php echo $item->quantity; ?></p>
                            <br>
                            <p class="product-name" style="
                                color: rgba(0, 0, 0, 0.5);
                                font-size: 0.8rem;
                                font-style: italic;">
                                product id <?php echo $item->productID; ?>
                            </p>
                            <!-- Add other details as needed -->
                            <p class="product-remove">
                                <a href="<?php echo base_url('cart/remove/' . $item->productID); ?>">
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    <span class="remove">Remove</span>
                                </a>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="cart-total">
				<p>
					<span>Total Price</span>
					<span>€
						<?php echo $totalPrice; ?>
					</span>
				</p>
				<p>
					<span>Number of Items</span>
					<span>
						<?php echo $totalItems; ?>
					</span>
				</p>
				<a href="<?php echo base_url('checkout'); ?>">Proceed to Checkout</a>

                <form action="<?php echo base_url('cart/add'); ?>" method="post">
                    <input type="hidden" name="product_id" value="1">
                    <input type="hidden" name="quantity" value="1">
                    <button type="submit">Add Product 1</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
