<!DOCTYPE html>
<html lang="en">

<?php
$base = base_url() . "/";
$controller_base = $base . "index.php/";
?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>McFaddens - Home</title>

  <link href="<?php echo $base . "assets/css/style.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/main.css" ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo $base . "assets/css/responsive.css" ?>" rel="stylesheet" type="text/css" />
  <style>
    .product-image {
      width: 30%;
      height: auto;
      max-width: 100%;
      display: block;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <div class="image-container always-on-top">
    <nav>
      <div class="wrapper">
        <div class="logo"><a href="#">McFaddens</a></div>
        <input type="radio" name="slider" id="menu-btn">
        <input type="radio" name="slider" id="close-btn">
        <ul class="nav-links">
          <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
          <li><a href="#">Home</a></li>
          <li><a href="#">Blog</a></li>
          <!-- ... Other menu items ... -->
          <li><a href="<?php echo base_url('cart'); ?>"><img src="<?php echo $base . "assets/images/cart.png" ?>"></a></li>
        </ul>
      </div>
    </nav>
  </div>

  <div class="grid-container">
    <?php foreach ($products as $product) : ?>
      <div class="box">
        <img class="product-image" src="<?php echo base_url("assets/images/g{$product['productID']}.jpg"); ?>" alt="Product Image">
        <h3 style="text-align:left;">Brand Name<span style="float:right;"><?php echo $product['price']; ?></span></h3>
        <p style="text-align:left;"><?php echo $product['productDesc']; ?></p>
        <form action="<?php echo base_url('cart/add'); ?>" method="post">
          <input type="hidden" name="product_id" value="<?php echo $product['productID']; ?>">
          <input name="quantity" value="1">
          <button type="submit" class="btn">Add to Cart</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>

  <footer class="footer">
    <p class="khula-regular">&#169; 2023 McFaddens Instruments. All rights reserved.</p>
  </footer>
</body>

</html>
