<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        // Show the confirmation dialog when the page loads
        if (confirm("Are you sure you want to delete this staff?")) {
            // If the user confirms, make an AJAX request to delete the product
            $.ajax({
                type: "POST",
                url: "<?= site_url('deleteStaff/' . $staffID) ?>",
                 data: {
        <?= csrf_token() ?>: '<?= csrf_hash() ?>',
    },
				success: function(response) {
                    // Display a success message to the user
                   // alert(response.message);
				   console.log(response);
                    // You can redirect or perform other actions as needed
					
					// Redirect to the addProduct page
                    window.location.href = '<?= base_url('viewStaff') ?>';
                },
                error: function() {
                    // Handle errors if necessary
                    alert('Error deleting staff');
                }
            });
        } else {
            // If the user cancels, you can redirect or perform other actions as needed
            alert('Deletion canceled');
        }
    });
</script>

