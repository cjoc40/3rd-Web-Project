<?php

namespace App\Models;

use CodeIgniter\Model;
use App\Models\CartModel;

/**
 * Class AuthenticationModel
 *
 * This class represents the model for authentication in the application.
 * It extends the CodeIgniter Model class and provides methods for user registration, login, and logout.
 *
 * @package App\Models
 */
class AuthenticationModel extends Model
{
    protected $table = 'webproject.users';
    protected $allowedFields = [
        'firstName',
        'lastName',
        'email',
        'phoneNum',
        'password',
        'address1',
        'address2',
        'town_city',
        'county',
        'session_id'
    ];
    protected $cartModel;

    public function __construct()
    {
        parent::__construct();
        $this->cartModel = new CartModel();
    }

    /**
     * Registers a new user.
     *
     * @param array $data The user data to be registered.
     * @return bool|int The ID of the inserted user or false on failure.
     */
    public function register($data)
    {
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);

        return $this->insert($data);
    }

    /**
     * Logs in a user with the given email and password.
     *
     * @param string $email The user's email.
     * @param string $password The user's password.
     * @return array|false The user data if login is successful, false otherwise.
     */
    public function login($email, $password)
    {
        if (!$email || !$password) {
            return false;
        }

        $user = $this->where('email', $email)->first();

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }

        return false;
    }

    /**
     * Check if the given email belongs to a staff member.
     *
     * @param string $email The email address to check.
     * @return bool Returns true if the email belongs to a staff member, false otherwise.
     */
    public function isStaff($email)
    {
        $staff = $this->db->table('webproject.staff')->where('email', $email)->get()->getRowArray();
        return $staff != null;
    }

    /**
     * Check if the staff member with the given email has full permissions.
     *
     * @param string $email The email address of the staff member.
     * @return bool Returns true if the staff member has full permissions, false otherwise.
     */
    public function fullStaffPermissions($email)
    {
        $staff = $this->db->table('webproject.staff')->where('email', $email)->get()->getRowArray();
        $permissions = trim(strtolower($staff['permissions']));
        return $permissions == 'full';
    }

    /**
     * Logs in the user and sets the session data.
     *
     * @param string $email The user's email.
     * @param string $password The user's password.
     * @return bool Returns true if the login is successful, false otherwise.
     */
    public function loginAndSession($email, $password)
    {
        $user = $this->login($email, $password);

        if ($user) {
            $sessionId = $this->getSessionId($user['id']);
            if ($sessionId != null && $sessionId != session_id()) {
                $this->cartModel->transferCart($sessionId, session_id());
            }

            session()->set([
                'isLoggedIn' => true,
                'id' => $user['id'],
                'isAdmin' => $this->isStaff($email) && $this->fullStaffPermissions($email)
            ]);

            $this->saveSessionId($user['id'], session_id());

            return true;
        } else {
            return false;
        }
    }

    /**
     * Checks if a user is logged in.
     *
     * @param bool $asAdmin If true, checks if the user is logged in as an admin.
     * @return bool Returns true if the user is logged in, false otherwise.
     */
    public function isLoggedIn($asAdmin = false)
    {
        if ($asAdmin) {
            return session()->get('isLoggedIn') && session()->get('isAdmin');
        } else {
            return session()->get('isLoggedIn');
        }
    }

    /**
     * Logs out the currently logged in user.
     *
     * @return void
     */
    public function logout()
    {
        session()->destroy();
    }

    /**
     * Saves the session ID for a given user ID.
     *
     * @param int $id The user ID.
     * @param string $sessionId The session ID to be saved.
     * @return bool Returns true if the session ID is successfully saved, false otherwise.
     */
    public function saveSessionId($id, $sessionId)
    {
        if (empty($id) || empty($sessionId)) {
            return false;
        }

        return $this->where('id', $id)->set('session_id', $sessionId)->update();
    }

    /**
     * Retrieves the session ID for a given user ID.
     *
     * @param int $id The user ID.
     * @return string|null Returns the session ID if found, null otherwise.
     */
    public function getSessionId($id)
    {
        $user = $this->where('id', $id)->first();
        return $user['session_id'];
    }
}