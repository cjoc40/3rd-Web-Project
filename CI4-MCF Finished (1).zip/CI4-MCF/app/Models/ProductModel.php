<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'productID';
    protected $allowedFields = ['productID', 'categoryID', 'warehouseID', 'supplierID', 'barcode', 'brand', 'productDesc', 'price', 'quantity', 'productAvailability'];

}
