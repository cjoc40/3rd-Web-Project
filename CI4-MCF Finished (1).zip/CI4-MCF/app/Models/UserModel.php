<?php

namespace App\Models;

use CodeIgniter\Controller;
use CodeIgniter\Model;

class UserModel extends Model
{
    protected $db;
	protected $table ='users';
	protected $primaryKey = 'id';
	
	protected $userAutoIncrement = true;
	protected $returnType = 'object';
	protected $userofDeletes= true;
	
	protected $allowedFields = ['name','username','email','password'];
	
	protected $validationRules =[];
	protected $validationMessages =[];
	protected $skipValidation = false;
	
	
  
}
