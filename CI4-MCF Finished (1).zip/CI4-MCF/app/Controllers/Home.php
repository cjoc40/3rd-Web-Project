<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;
use App\Models\AuthenticationModel;

class Home extends BaseController
{
    protected $db;
    protected $session;
    protected $auth;
    protected $shoppingCartController;
	protected $validation;

    public function __construct()
    {
        helper(['form', 'url']);
		

        $this->db = db_connect(); // Load the database
        $this->session = session();
        $this->auth = new AuthenticationModel();
        $this->shoppingCartController = new ShoppingCartController();
		$this->validation = \Config\Services::validation();
		

    }

    public function index()
    {
        return view('mcfadden/index');
    }

    public function admin()
    {
        if (!$this->auth->isLoggedIn( /* As Admin: */true)) {
            return $this->login();
        }

        return view('mcfadden/admin');
    }

    public function cart()
    {
        return $this->shoppingCartController->viewCart();
    }

    public function login()
    {
        if ($this->auth->isLoggedIn()) {
            if ($this->auth->isLoggedIn(true)) {
                return redirect()->to(base_url('admin'));
            } else {
                return redirect()->to(base_url());
            }
        }

        return view('mcfadden/login');
    }

    public function logout()
    {
        $this->auth->logout();
        return redirect()->to(base_url());
    }

    public function register()
    {
        if ($this->auth->isLoggedIn()) {
            if ($this->auth->isLoggedIn(true)) {
                return redirect()->to(base_url('admin'));
            } else {
                return redirect()->to(base_url());
            }
        }

        return view('mcfadden/register');
    }

    public function Productdetails()
    {
        $productModel = new \App\Models\ProductModel();

        // Fetch all products
        $productData = $productModel->findAll();

        $data['products'] = $productData;

        return view('mcfadden/productdetails', $data);
    }

    public function addProduct()
    {
        // Fetch products and categories from the database
        $db = db_connect();
        $products = $db->query('SELECT p.*, c.categoryName FROM products p
                       LEFT JOIN category c ON p.categoryID = c.categoryID')
            ->getResult();
        $categories = $db->table('category')->get()->getResult();

        // Pass the products and categories to the view
        return view('mcfadden/addProduct', ['products' => $products, 'categories' => $categories]);
    }
    public function updateProduct($productID)
    {
        $db = db_connect();
        $data = [];

        if (empty($productID)) {
            return redirect()->to('addProduct');
        }

        if ($this->request->getMethod() === 'post') {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'barcode' => 'required',
            'brand' => 'required',
            'productDesc' => 'required',
            'price' => 'required',
            'quantity' => 'required',
            'productAvailability' => 'required',
        ]);

            if ($validation->withRequest($this->request)->run()) {
                $productData = [
                'barcode' => $this->request->getPost('barcode'),
                'brand' => $this->request->getPost('brand'),
                'productDesc' => $this->request->getPost('productDesc'),
                'price' => $this->request->getPost('price'),
                'quantity' => $this->request->getPost('quantity'),
                'productAvailability' => $this->request->getPost('productAvailability'),
                ];

                $db->table('products')->update($productData, ['productID' => $productID]);
                return redirect()->to('addProduct');

            } else {
                $data['validation'] = $validation;
            }
        }

        $product = $db->table('products')->where('productID', $productID)->get()->getRow();
        $data['product'] = $product;

        return view('mcfadden/updateProduct', $data);
    }
	


    public function updateCategory($categoryID)
    {
        $db = db_connect();
        $data = [];
		
		  if (empty($categoryID)) {
            return redirect()->to('viewCategories');
        }
		
		if ($this->request->getMethod() === 'post') {
        $validation = \Config\Services::validation();
        $validation->setRules([
           'categoryName' => 'required',
        ]);

            if ($validation->withRequest($this->request)->run()) {
                $categoryData = [
                    'categoryName' => $this->request->getPost('categoryName'),
                ];

                $db->table('category')->update($categoryData, ['categoryID' => $categoryID]);
                return redirect()->to('viewCategories'); // Make sure 'viewCategory' is a valid route
            } else {
                $data['validation'] = $validation;
            }
        }

        $category = $db->table('category')->where('categoryID', $categoryID)->get()->getRow();
        $data['category'] = $category;

        return view('mcfadden/updateCategory', $data);
    }
	
	public function updateMember($memberID)
{
    $db = db_connect();
    $data = [];

    if (empty($memberID)) {
        return redirect()->to('viewMembers');
    }

    if ($this->request->getMethod() === 'post') {
        $validation = \Config\Services::validation();
        $validation->setRules([
			'memberID' => 'required',
            'firstName' => 'required',
            'lastName' => 'required',
            'email' => 'required|valid_email',
            'phoneNum' => 'required',
            'passWord' => 'required|min_length[6]',
            'address1' => 'required',
            'address2' => 'required',
            'town_city' => 'required',
            'county' => 'required',
        ]);

        if ($validation->withRequest($this->request)->run()) {
            $memberData = [
				'memberID' => $this->request->getPost('memberID'),
                'firstName' => $this->request->getPost('firstName'),
                'lastName' => $this->request->getPost('lastName'),
                'email' => $this->request->getPost('email'),
                'phoneNum' => $this->request->getPost('phoneNum'),
                'passWord' => password_hash($this->request->getPost('passWord'), PASSWORD_BCRYPT),
                'address1' => $this->request->getPost('address1'),
                'address2' => $this->request->getPost('address2'),
                'town_city' => $this->request->getPost('town_city'),
                'county' => $this->request->getPost('county'),
            ];

            $db->table('member')->update($memberData, ['memberID' => $memberID]);
            return redirect()->to('viewMembers');
        } else {
            $data['validation'] = $validation;
        }
    }

    $member = $db->table('member')->where('memberID', $memberID)->get()->getRow();
    $data['member'] = $member;

    return view('mcfadden/updateMember', $data);
}
	
	public function updateStaff($staffID)
{
    $db = db_connect();
    $data = [];

    if (empty($staffID)) {
        return redirect()->to('viewStaff');
    }

    if ($this->request->getMethod() === 'post') {
        $validation = \Config\Services::validation();
        $validation->setRules([
			'staffID' => 'required',
            'firstName' => 'required',
            'lastName' => 'required',
            'email' => 'required',
            'phoneNum' => 'required',
            'passWord' => 'required',
            'positions' => 'required',
            'permissions' => 'required',
            'hireDate' => 'required',
            'dateOfBirth' => 'required',
        ]);

        if ($validation->withRequest($this->request)->run()) {
            $staffData = [
				'staffID' => $this->request->getPost('staffID'),
                'firstName' => $this->request->getPost('firstName'),
                'lastName' => $this->request->getPost('lastName'),
                'email' => $this->request->getPost('email'),
                'phoneNum' => $this->request->getPost('phoneNum'),
                'passWord' => password_hash($this->request->getPost('passWord'), PASSWORD_BCRYPT),
                'positions' => $this->request->getPost('positions'),
                'permissions' => $this->request->getPost('permissions'),
                'hireDate' => $this->request->getPost('hireDate'),
                'dateOfBirth' => $this->request->getPost('dateOfBirth'),
            ];

            $db->table('staff')->update($staffData, ['staffID' => $staffID]);
            return redirect()->to('viewStaff');
        } else {
            $data['validation'] = $validation;
        }
    }

    $staff = $db->table('staff')->where('staffID', $staffID)->get()->getRow();
    $data['staff'] = $staff;

    return view('mcfadden/updateStaff', $data);
}





    public function viewStaff()
    {
        $db = db_connect();
        $query = $db->table('staff')->get();
        $data['staffs'] = $query->getResult();
        return view('mcfadden/viewStaff', $data);
    }


    public function viewMembers()
    {
        $db = db_connect();
        $query = $db->table('member')->get();
        $data['members'] = $query->getResult();
        return view('mcfadden/viewMembers', $data);
    }


    public function viewCategories()
    {
        $db = db_connect();
        $query = $db->table('category')->get();
        $data['categories'] = $query->getResult();
        return view('mcfadden/viewCategories', $data);
    }
    public function viewProduct()
    {
        $db = db_connect();
        $query = $db->table('products')->get();
        $data['products'] = $query->getResult();
        return view('mcfadden/viewProduct', $data);
    }

    public function newMember()
    {
        return view('mcfadden/newMember');
    }
    public function newStaff()
    {
        return view('mcfadden/newStaff');
    }
    public function newProduct()
    {
        // Fetch categories from the database
        $db = db_connect();
        $categories = $db->table('category')->get()->getResult();

        // Pass the categories to the view
        return view('mcfadden/newProduct', ['categories' => $categories]);
    }
    public function newCategory()
    {
        return view('mcfadden/newCategory');
    }
    public function deleteMessage()
    {
        return view('mcfadden/deleteMessage');
    }
	

	

    public function addMember()
    {
        $db = db_connect();

        // Check if the form has been submitted
        if ($this->request->getMethod() === 'post') {

            // Retrieve member data from the form
            $memberData = [
                'firstName' => $this->request->getPost('firstName'),
                'lastName' => $this->request->getPost('lastName'),
                'email' => $this->request->getPost('email'),
                'phoneNum' => $this->request->getPost('phoneNum'),
                'passWord' => password_hash($this->request->getPost('passWord'), PASSWORD_BCRYPT),
                // Hash the password
                'address1' => $this->request->getPost('address1'),
                'address2' => $this->request->getPost('address2'),
                'town_city' => $this->request->getPost('town_city'),
                'county' => $this->request->getPost('county'),
            ];

            // Insert the data into the 'member' table
            $db->table('member')->insert($memberData);

            // Reset the auto-increment value to 1
            $db->query("ALTER TABLE products AUTO_INCREMENT = 1");

            // Redirect to the product list after adding
            return redirect()->to(base_url('viewMembers'));

        }
        // If the form has not been submitted, just load the view without adding a product
        return view('mcfadden/viewMembers');
    }
	

	
	public function addStaff()
    {
        $db = db_connect();

        
		   // Check if the form has been submitted
        if ($this->request->getMethod() === 'post') { 
		  
        $staffData = [
            'firstName' => $this->request->getPost('firstName'),
            'lastName' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'phoneNum' => $this->request->getPost('phoneNum'),
            'passWord' => password_hash($this->request->getPost('passWord'), PASSWORD_BCRYPT),
            'positions' => $this->request->getPost('positions'),
            'permissions' => $this->request->getPost('permissions'),
            'hireDate' => $this->request->getPost('hireDate'),
            'dateOfBirth' => $this->request->getPost('dateOfBirth'),
        ];

        // Insert the data into the 'staff' table
        $db->table('staff')->insert($staffData);
			
		// Reset the auto-increment value to 1
        $db->query("ALTER TABLE products AUTO_INCREMENT = 1");

        // Redirect to the product list after adding
            return redirect()->to(base_url('viewStaff'));
		}

        return view('mcfadden/viewStaff'); // Redirect to the staff list after adding
    }
	
	
	
    public function addProduct2()
    {
        $db = db_connect();


        // Check if the form has been submitted
        if ($this->request->getMethod() === 'post') {

            $categoryID = $this->request->getPost('categoryID');
            $categoryName = $this->request->getPost('categoryName');

            // Retrieve product data from the form
            $productData = [
                // Retrieve form data including the selected category ID
                'categoryID' => $categoryID,
                'warehouseID' => $this->request->getPost('warehouseID'),
                'supplierID' => $this->request->getPost('supplierID'),
                'barcode' => $this->request->getPost('barcode'),
                'brand' => $this->request->getPost('brand'),
                'productDesc' => $this->request->getPost('productDesc'),
                'price' => $this->request->getPost('price'),
                'quantity' => $this->request->getPost('quantity'),
                'productAvailability' => $this->request->getPost('productAvailability'),
            ];

            // Insert the data into the 'products' table
            $db->table('products')->insert($productData);

            // Reset the auto-increment value to 1
            $db->query("ALTER TABLE products AUTO_INCREMENT = 1");

            // Redirect to the product list after adding
            return redirect()->to('addProduct')->with('success', 'Product added successfully');
        }

        // If the form has not been submitted, just load the view without adding a product
        return view('mcfadden/addProduct');
    }
	


    public function addCategory()
    {
        $db = db_connect();

        // Check if the form has been submitted
        if ($this->request->getMethod() === 'post') {

            // Retrieve product data from the form
            $categoryData = [
                'categoryID' => $this->request->getPost('categoryID'),
                'categoryName' => $this->request->getPost('categoryName'),
            ];

            // Insert the data into the 'category' table
            $db->table('category')->insert($categoryData);

            // Reset the auto-increment value to 1
            $db->query("ALTER TABLE category AUTO_INCREMENT = 1");

            // Redirect to the product list after adding
            return redirect()->to(base_url('viewCategories'));
        }

        // If the form has not been submitted, just load the view without adding a product
        return view('mcfadden/viewCategories');
    }
    public function deleteProduct($productID)
    {
        if ($this->request->isAJAX()) {
            // If the request is AJAX, it means it's coming from the confirmation dialog

            log_message('debug', 'AJAX request received');

            $db = db_connect();

            // Delete the product
            $db->table('products')->where('productID', $productID)->delete();

            // Get the current maximum productID value
            $maxIDQuery = $db->query("SELECT MAX(productID) as maxID FROM products");
            $maxIDResult = $maxIDQuery->getRow();
            $maxID = $maxIDResult->maxID;

            // Reset the auto-increment value
            $newAutoIncrementValue = $maxID + 1;
            $db->query("ALTER TABLE products AUTO_INCREMENT = $newAutoIncrementValue");

            // Debugging: Add a log statement to check if there are any errors
            log_message('debug', 'Deletion and reset successful');

            // Return a success message (this will be sent back to the AJAX request)
            return $this->response->setJSON(['status' => 'success', 'message' => 'Product deleted successfully']);


        }
        return view('mcfadden/deleteMessageP', ['productID' => $productID]);


    }
    public function deleteMember($memberID)
    {
        if ($this->request->isAJAX()) {
            // If the request is AJAX, it means it's coming from the confirmation dialog

            log_message('debug', 'AJAX request received');

            $db = db_connect();

            // Delete the product
            $db->table('member')->where('memberID', $memberID)->delete();

            // Get the current maximum productID value
            $maxIDQuery = $db->query("SELECT MAX(memberID) as maxID FROM member");
            $maxIDResult = $maxIDQuery->getRow();
            $maxID = $maxIDResult->maxID;

            // Reset the auto-increment value
            $newAutoIncrementValue = $maxID + 1;
            $db->query("ALTER TABLE member AUTO_INCREMENT = $newAutoIncrementValue");

            // Debugging: Add a log statement to check if there are any errors
            log_message('debug', 'Deletion and reset successful');

            // Return a success message (this will be sent back to the AJAX request)
            return $this->response->setJSON(['status' => 'success', 'message' => 'Member deleted successfully']);


        }
        return view('mcfadden/deleteMessageM', ['memberID' => $memberID]);


    }
	
	public function deleteStaff($staffID)
    {
        if ($this->request->isAJAX()) {
            // If the request is AJAX, it means it's coming from the confirmation dialog

            log_message('debug', 'AJAX request received');

            $db = db_connect();

            // Delete the product
            $db->table('staff')->where('staffID', $staffID)->delete();

            // Get the current maximum productID value
            $maxIDQuery = $db->query("SELECT MAX(staffID) as maxID FROM staff");
            $maxIDResult = $maxIDQuery->getRow();
            $maxID = $maxIDResult->maxID;

            // Reset the auto-increment value
            $newAutoIncrementValue = $maxID + 1;
            $db->query("ALTER TABLE staff AUTO_INCREMENT = $newAutoIncrementValue");

            // Debugging: Add a log statement to check if there are any errors
            log_message('debug', 'Deletion and reset successful');

            // Return a success message (this will be sent back to the AJAX request)
            return $this->response->setJSON(['status' => 'success', 'message' => 'Member deleted successfully']);


        }
        return view('mcfadden/deleteMessageS', ['staffID' => $staffID]);


    }


    public function deleteCategory($categoryID)
    {
        if ($this->request->isAJAX()) {
            // If the request is AJAX, it means it's coming from the confirmation dialog

            log_message('debug', 'AJAX request received');

            $db = db_connect();

            // Delete the product
            $db->table('category')->where('categoryID', $categoryID)->delete();

            // Get the current maximum productID value
            $maxIDQuery = $db->query("SELECT MAX(categoryID) as maxID FROM category");
            $maxIDResult = $maxIDQuery->getRow();
            $maxID = $maxIDResult->maxID;

            // Reset the auto-increment value
            $newAutoIncrementValue = $maxID + 1;
            $db->query("ALTER TABLE category AUTO_INCREMENT = $newAutoIncrementValue");

            // Debugging: Add a log statement to check if there are any errors
            log_message('debug', 'Deletion and reset successful');

            // Return a success message (this will be sent back to the AJAX request)
            return $this->response->setJSON(['status' => 'success', 'message' => 'Category deleted successfully']);


        }
        return view('mcfadden/deleteMessageC', ['categoryID' => $categoryID]);


    }



    public function queryDatabase()
    {
        $query = $this->db->query("SELECT * FROM your_table_name");
        $result = $query->getResult();

        foreach ($result as $row) {
            echo $row->column_name . "<br>";
        }
    }

    public function do_register()
    {
        $userModel = new UserModel();

        $name = $this->request->getPost('name');
        $username = $this->request->getPost('username');
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        // Trim the password to remove any leading or trailing whitespaces
        $password = trim($password);

        // Hash the password
        $hash_password = password_hash($password, PASSWORD_DEFAULT);

        // Debugging: Print password and hashed password
        echo "Password before hashing: " . $password . "<br>";
        echo "Hash from registration: " . $hash_password . "<br>";

        // Prepare data for insertion
        $data = ['name' => $name, 'username' => $username, 'email' => $email, 'password' => $hash_password];

        // Insert data into the database
        $r = $userModel->insert($data);

        if ($r) {
            return view('mcfadden/login');
        } else {
            echo "Error in the registration process";
        }
    }


    public function do_login()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        if (empty($email) || empty($password)) {
            echo "Email or password is empty";
            return;
        }
        
        $password = trim($password);
        $this->auth->loginAndSession($email, $password);

        if ($this->auth->isLoggedIn()) {
            if ($this->auth->isLoggedIn(true)) {
                return redirect()->to(base_url('admin'));
            } else {
                return redirect()->to(base_url());
            }
        } else {
            echo "Login failed";
        }
    }

    public function setAdmin()
    {
        if (ENVIRONMENT == 'production') {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound(
                "This page is not available in production mode"
            );
        }

        $this->session->set('isAdmin', true);
        return redirect()->to(base_url('admin'));
    }
}
