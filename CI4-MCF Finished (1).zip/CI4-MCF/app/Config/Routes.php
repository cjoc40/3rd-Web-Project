<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setDefaultController('Home');


// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
$routes->get('/admin','Home::admin');

$routes->get('/login','Home::login');
$routes->get('/register','Home::register');
$routes->get('/logout','Home::logout');
$routes->get('/testadmin','Home::setAdmin');

$routes->get('/cart','Home::cart');
$routes->post('cart/add', 'ShoppingCartController::addToCart');
$routes->get('cart/remove/(:segment)', 'ShoppingCartController::removeFromCart/$1');

$routes->post('/register','Home::do_register');
$routes->post('/login','Home::do_login');
$routes->get('/deleteMessageP','Home::deleteMessageP');
$routes->get('/deleteMessageM','Home::deleteMessageM');
$routes->get('/deleteMessageC','Home::deleteMessageC');
$routes->get('/deleteMessageS','Home::deleteMessageS');


$routes->get('viewMembers', 'Home::viewMembers');
$routes->get('newMember', 'Home::newMember');
$routes->post('newMember', 'Home::addMember');

$routes->get('deleteMember/(:num)', 'Home::deleteMember/$1');
$routes->post('deleteMember/(:num)', 'Home::deleteMember/$1');

$routes->get('updateMember/(:num)', 'Home::updateMember/$1');
$routes->post('updateMember/(:num)', 'Home::updateMember/$1');

$routes->get('newProduct', 'Home::newProduct');
$routes->post('newProduct', 'Home::addProduct2');

$routes->get('addProduct', 'Home::addProduct');

$routes->get('updateProduct/(:num)', 'Home::updateProduct/$1');
$routes->post('updateProduct/(:num)', 'Home::updateProduct/$1');


$routes->get('deleteProduct/(:num)', 'Home::deleteProduct/$1');
$routes->post('deleteProduct/(:num)', 'Home::deleteProduct/$1');

$routes->get('viewProduct', 'Home::viewProduct');
$routes->get('viewStaff', 'Home::viewStaff');
$routes->get('newStaff', 'Home::newStaff');
$routes->post('newStaff', 'Home::addStaff');

$routes->get('updateStaff/(:num)', 'Home::updateStaff/$1');
$routes->post('updateStaff/(:num)', 'Home::updateStaff/$1');

$routes->get('deleteStaff/(:num)', 'Home::deleteStaff/$1');
$routes->post('deleteStaff/(:num)', 'Home::deleteStaff/$1');

$routes->get('viewCategories', 'Home::viewCategories');
$routes->get('newCategory', 'Home::newCategory');
$routes->post('newCategory', 'Home::addCategory');

$routes->get('updateCategory/(:num)', 'Home::updateCategory/$1');
$routes->post('updateCategory/(:num)', 'Home::updateCategory/$1');

$routes->get('deleteCategory/(:num)', 'Home::deleteCategory/$1');
$routes->post('deleteCategory/(:num)', 'Home::deleteCategory/$1');

$routes->match(['get', 'post'], 'updateCategory/(:num)', 'Home::updateCategory/$1');

//$routes->get('cart', 'ShoppingCartController::viewCart');
//$routes->post('cart/addToCart', 'ShoppingCartController::addToCart');
$routes->get('productdetails', 'Home::Productdetails');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
