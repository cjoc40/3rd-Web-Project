<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Home extends BaseController
{
    protected $db;

    public function __construct()
    {
        $this->db = db_connect(); // Load the database
    }

    public function index()
    {
        return view('mcfadden/index');
    }

    public function admin()
    {
        return view('mcfadden/admin');
    }

    public function addProduct()
    {
        $db = db_connect();
        $query = $db->table('products')->get();
        $data['products'] = $query->getResult();

        return view('mcfadden/addProduct', $data);
    }

    public function viewStaff()
    {
        $db = db_connect();
        $query = $db->table('staff')->get();
        $data['staff'] = $query->getResult();
        return view('mcfadden/viewStaff', $data);
    }


    public function viewMembers()
    {
        $db = db_connect();
        $query = $db->table('member')->get();
        $data['members'] = $query->getResult();
        return view('mcfadden/viewMembers', $data);
    }


    public function viewCategories()
    {
        $db = db_connect();
        $query = $db->table('category')->get();
        $data['categories'] = $query->getResult();
        return view('mcfadden/viewCategories', $data);
    }

    public function newMember()
    {
        return view('mcfadden/newMember');
    }
    public function newStaff()
    {
        return view('mcfadden/newStaff');
    }
    public function newProduct()
    {
        return view('mcfadden/newProduct');
    }
    public function newCategory()
    {
        return view('mcfadden/newCategory');
    }

    public function addMember()
    {
        $db = db_connect();

        // Retrieve member data from the form
        $memberData = [
            'firstName' => $this->request->getPost('firstName'),
            'lastName' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'phoneNum' => $this->request->getPost('phoneNum'),
            'passWord' => password_hash($this->request->getPost('passWord'), PASSWORD_BCRYPT),
            // Hash the password
            'address1' => $this->request->getPost('address1'),
            'address2' => $this->request->getPost('address2'),
            'town_city' => $this->request->getPost('town_city'),
            'county' => $this->request->getPost('county'),
        ];

        // Insert the data into the 'member' table
        $db->table('member')->insert($memberData);

        // Load the members again after the addition
        $query = $db->table('member')->get();
        $data['members'] = $query->getResult();

        // Redirect to the member list after adding
        return view('mcfadden/viewMembers', $data);
    }
    public function addProduct2()
    {
        $db = db_connect();

        // Check if the form has been submitted
        if ($this->request->getMethod() === 'post') {

            // Retrieve product data from the form
            $productData = [
                'categoryID' => $this->request->getPost('categoryID'),
                'warehouseID' => $this->request->getPost('warehouseID'),
                'supplierID' => $this->request->getPost('supplierID'),
                'barcode' => $this->request->getPost('barcode'),
                'brand' => $this->request->getPost('brand'),
                'productDesc' => $this->request->getPost('productDesc'),
                'price' => $this->request->getPost('price'),
                'quantity' => $this->request->getPost('quantity'),
                'productAvailability' => $this->request->getPost('productAvailability'),
            ];

            // Insert the data into the 'products' table
            $db->table('products')->insert($productData);

            // Reset the auto-increment value to 1
            $db->query("ALTER TABLE products AUTO_INCREMENT = 1");

            // Redirect to the product list after adding
            return redirect()->to(base_url('addProduct'));
        }

        // If the form has not been submitted, just load the view without adding a product
        return view('mcfadden/addProduct');
    }

    public function deleteProduct($productID)
    {
        $db = db_connect();

        // Delete the product
        $db->table('products')->where('productID', $productID)->delete();

        // Get the current maximum productID value
        $maxIDQuery = $db->query("SELECT MAX(productID) as maxID FROM products");
        $maxIDResult = $maxIDQuery->getRow();
        $maxID = $maxIDResult->maxID;

        // Reset the auto-increment value
        $newAutoIncrementValue = $maxID + 1;
        $db->query("ALTER TABLE products AUTO_INCREMENT = $newAutoIncrementValue");

        // Redirect to the addProduct page
        return redirect()->to(site_url('addProduct'));
    }
    public function addStaff()
    {
        $db = db_connect();

        // Retrieve staff data from the form
        $staffData = [
            'firstName' => $this->request->getPost('firstName'),
            'lastName' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'phoneNum' => $this->request->getPost('phoneNum'),
            'passWord' => password_hash($this->request->getPost('passWord'), PASSWORD_BCRYPT),
            'positions' => $this->request->getPost('positions'),
            'permissions' => $this->request->getPost('permissions'),
            'hireDate' => $this->request->getPost('hireDate'),
            'dateOfBirth' => $this->request->getPost('dateOfBirth'),
        ];

        // Insert the data into the 'staff' table
        $db->table('staff')->insert($staffData);

        $query = $db->table('staff')->get();
        $data['staff'] = $query->getResult();

        return view('mcfadden/viewStaff', $data); // Redirect to the staff list after adding
    }
    public function addCategory()
    {
        $db = db_connect();

        // Retrieve category data from the form
        $categoryData = [
            'productID' => $this->request->getPost('productID'),
            'categoryName' => $this->request->getPost('categoryName'),
            'description' => $this->request->getPost('description'),
            'picture' => $this->request->getPost('picture'),
        ];

        // Insert the data into the 'category' table
        $db->table('category')->insert($categoryData);

        $query = $db->table('category')->get();
        $data['categories'] = $query->getResult();

        return view('mcfadden/viewCategories', $data); // Redirect to the category list after adding
    }

    public function queryDatabase()
    {
        $query = $this->db->query("SELECT * FROM your_table_name");
        $result = $query->getResult();

        foreach ($result as $row) {
            echo $row->column_name . "<br>";
        }
    }
}
